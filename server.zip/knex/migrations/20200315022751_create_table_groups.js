exports.up = (knex) => knex.schema.createTable('groups', (table) => {
  table.increments()
  table.integer('owner_id').notNullable().unsigned()
  table.foreign('owner_id').references('id').inTable('users')
    .onUpdate('CASCADE')
    .onDelete('RESTRICT')
  table.string('groupname').notNullable()
  table.timestamp('created_at').default(knex.fn.now())
  table.timestamp('updated_at').default(knex.fn.now())
})

exports.down = (knex) => knex.schema.dropTableIfExists('groups')
